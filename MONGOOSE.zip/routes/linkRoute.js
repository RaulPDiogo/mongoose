const express = require('express')
const route = express.Router();
const methodOverride = require('method-override')
route.use(methodOverride('_method'))
const linkControle = require('../controle/linkControle')

route.get('/', linkControle.allLinks),

route.get('/:title', linkControle.redirect);

(route.get('/add',(req,res) => res.render('index',{error: false, body: {}})), ()=> console.error('deu ruim'))

route.post('/', express.urlencoded({extended: true}), linkControle.addLink);

route.delete('/:id',linkControle.deleteLink)
route.delete('/',express.urlencoded({extended: true}),linkControle.deleteLink)

module.exports = route